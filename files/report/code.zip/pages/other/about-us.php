<?php
  include_once('../../config/init.php');
  
  $smarty->display('other/about-us.tpl');
?>
