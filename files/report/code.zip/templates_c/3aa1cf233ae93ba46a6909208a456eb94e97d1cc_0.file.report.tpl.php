<?php
/* Smarty version 3.1.30, created on 2018-01-07 02:50:39
  from "C:\www\TrabalhoPHP-2\templates\other\report.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a517cef6987c0_72378524',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3aa1cf233ae93ba46a6909208a456eb94e97d1cc' => 
    array (
      0 => 'C:\\www\\TrabalhoPHP-2\\templates\\other\\report.tpl',
      1 => 1515289823,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/header.tpl' => 1,
    'file:common/footer.tpl' => 1,
  ),
),false)) {
function content_5a517cef6987c0_72378524 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:common/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<section>
  <h1>
    Relatório
  </h1>

  <section id="report">
	<p>
    Aqui poderá efetuar o download dos ficheiros de código HTML, PHP e CSS, bem como o PowerPoint mockup da ideia original para a construção deste site, sendo que entretanto, este sofreu ligeiras alterações ao nível de design, não se revelando significativas para uma reformulação do mockup.
  </p>
  <p>
    Para uma maior colaboração ao nível de desenvolvimento desta plataforma foi utilizado um repositório de software online, baseado na tecnologia Git, localizado em <a href="https://github.com/samagalhaes/SSMovies" class="GitHub">GitHub SSMovies</a>.
  </p>


	<section class="flexbox3">
		<a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
files/report/mockup.pdf" target="_blank"><img src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
img/report/ppt.png" alt="Mockup Powerpoint"></a>
		<a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
files/report/code.zip" target="_blank"><img src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
img/report/code.png" alt="Código PHP"></a>
		<a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/style.css" target="_blank"><img src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
img/report/css.png" alt="Código CSS"></a>
	</section>
</section>

<?php $_smarty_tpl->_subTemplateRender("file:common/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
