<?php
/* Smarty version 3.1.30, created on 2018-01-07 02:13:31
  from "C:\www\TrabalhoPHP-2\templates\order\cart.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a51743b4b45f0_85171692',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3463606c22cd04e72fdb1262e05f02f3739dc3d4' => 
    array (
      0 => 'C:\\www\\TrabalhoPHP-2\\templates\\order\\cart.tpl',
      1 => 1515264453,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/header.tpl' => 1,
    'file:common/footer.tpl' => 1,
  ),
),false)) {
function content_5a51743b4b45f0_85171692 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:common/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<section id="cartList">
  <h1>
    Carrinho de compras
  </h1>

  <section>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['cart']->value, 'film');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['film']->value) {
?>
      <form class="film" action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/order/cart.php" method="GET">
        <img src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
img/films/cover/covers/<?php echo $_smarty_tpl->tpl_vars['film']->value['id'];?>
.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['film']->value['nome'];?>
">
        <div class="description">
          <p class="title"><?php echo $_smarty_tpl->tpl_vars['film']->value['nome'];?>
</p>
          <p class="Particulars"><?php echo $_smarty_tpl->tpl_vars['film']->value['ano'];?>
 | M<?php echo $_smarty_tpl->tpl_vars['film']->value['classificacao_etaria'];?>
 | <?php echo $_smarty_tpl->tpl_vars['film']->value['genero'];?>
 | <?php echo $_smarty_tpl->tpl_vars['film']->value['duracao'];?>
min. | IMDB <?php echo $_smarty_tpl->tpl_vars['film']->value['pontuacao_imdb'];?>
</p>
        </div>
        <p class="price"><?php echo number_format($_smarty_tpl->tpl_vars['film']->value['preco'],2,',','.');?>
 &euro; x </p>
        <input type="number" name="qt" value="<?php echo $_smarty_tpl->tpl_vars['film']->value['qt'];?>
" pattern="[0-9]">
        <p class="total"><?php echo number_format(($_smarty_tpl->tpl_vars['film']->value['preco']*$_smarty_tpl->tpl_vars['film']->value['qt']),2,',','.');?>
 &euro;</p>
        <div class="buttons">
          <input type="text" name="id" value="<?php echo $_smarty_tpl->tpl_vars['film']->value['id'];?>
" hidden>
          <button type="submit" name="updateQt"><i class="fas fa-check-circle fa-2x"></i></button> <br>
          <button type="submit" name="delete"><i class="fas fa-times-circle fa-2x"></i></button>
        </div>
      </form>
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>


    <?php if (($_smarty_tpl->tpl_vars['total']->value != 0)) {?>
      <form class="submit" action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/order/cart.php" method="POST">
        <p><b>Valor total:</b> <?php echo number_format($_smarty_tpl->tpl_vars['total']->value,2,',','.');?>
 &euro;</p>
        <input type="submit" name="confirm" value="Confirmar">
      </form>
    <?php } else { ?>
      <p id="cleanCart">
        Adicione um produto ao carrinho de compras!
      </p>
    <?php }?>
  </section>
</section>

<?php $_smarty_tpl->_subTemplateRender("file:common/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
