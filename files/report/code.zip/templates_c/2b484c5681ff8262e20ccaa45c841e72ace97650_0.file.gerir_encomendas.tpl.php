<?php
/* Smarty version 3.1.30, created on 2018-01-07 02:59:40
  from "C:\www\TrabalhoPHP-2\templates\encomendas\gerir_encomendas.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a517f0c0a8895_76151072',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2b484c5681ff8262e20ccaa45c841e72ace97650' => 
    array (
      0 => 'C:\\www\\TrabalhoPHP-2\\templates\\encomendas\\gerir_encomendas.tpl',
      1 => 1515290357,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/header.tpl' => 1,
    'file:common/footer.tpl' => 1,
  ),
),false)) {
function content_5a517f0c0a8895_76151072 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_modifier_date_format')) require_once 'C:\\www\\TrabalhoPHP-2\\lib\\smarty\\plugins\\modifier.date_format.php';
if (!is_callable('smarty_function_html_options')) require_once 'C:\\www\\TrabalhoPHP-2\\lib\\smarty\\plugins\\function.html_options.php';
$_smarty_tpl->_subTemplateRender("file:common/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<section id="gerir_encomendas">
	<h1>
		Gerir encomendas
	</h1>
	<section class="tabela_encomendas">
		<table class="list clickable">
			<tr>
				<th>Código</th>
				<th>Data de Início</th>
				<th>Data de Fim</th>
				<th>Cliente</th>
				<th>Estado da Compra</th>
				<th></th>
			</tr>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['encomendas']->value, 'encomenda');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['encomenda']->value) {
?>
				<form method="POST" action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/encomendas/edit_estado.php?cod_encomenda=<?php echo $_smarty_tpl->tpl_vars['encomenda']->value['codigo'];?>
" autocomplete="on">
					<tr style="text-align:center">
						<td onclick="window.location = '<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/encomendas/gerir_encomenda.php?cod_encomenda=<?php echo $_smarty_tpl->tpl_vars['encomenda']->value['codigo'];?>
'">
							<?php echo $_smarty_tpl->tpl_vars['encomenda']->value['codigo'];?>

						</td>
						<td onclick="window.location = '<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/encomendas/gerir_encomenda.php?cod_encomenda=<?php echo $_smarty_tpl->tpl_vars['encomenda']->value['codigo'];?>
'">
							<?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['encomenda']->value['data_inicio'],"%d/%m/%y");?>

						</td>
						<td onclick="window.location = '<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/encomendas/gerir_encomenda.php?cod_encomenda=<?php echo $_smarty_tpl->tpl_vars['encomenda']->value['codigo'];?>
'">
							<?php ob_start();
echo $_smarty_tpl->tpl_vars['encomenda']->value['data_fim'];
$_prefixVariable1=ob_get_clean();
if ($_prefixVariable1) {?>
								<?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['encomenda']->value['data_fim'],"%d/%m/%y");?>

							<?php }?>
						</td onclick="window.location = '<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/encomendas/gerir_encomenda.php?cod_encomenda=<?php echo $_smarty_tpl->tpl_vars['encomenda']->value['codigo'];?>
'">
						<td>
							<?php echo $_smarty_tpl->tpl_vars['encomenda']->value['nome'];?>

						</td>
						<td>
							<?php echo smarty_function_html_options(array('name'=>'estado','options'=>$_smarty_tpl->tpl_vars['myOptions']->value,'selected'=>$_smarty_tpl->tpl_vars['encomenda']->value['id']),$_smarty_tpl);?>

						</td>
						<td>
							<button type="submit" name="confirmar"/><i class="fa fa-check-circle fa-2x" aria-hidden="true"></i></button>
						</td>
					</tr>
				</form>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

		</table>
	</section>
</section>

<?php $_smarty_tpl->_subTemplateRender("file:common/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
