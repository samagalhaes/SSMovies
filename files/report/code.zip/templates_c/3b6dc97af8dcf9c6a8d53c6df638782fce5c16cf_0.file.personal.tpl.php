<?php
/* Smarty version 3.1.30, created on 2018-01-07 02:54:18
  from "C:\www\TrabalhoPHP-2\templates\user\personal.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a517dca47ecc8_94909403',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3b6dc97af8dcf9c6a8d53c6df638782fce5c16cf' => 
    array (
      0 => 'C:\\www\\TrabalhoPHP-2\\templates\\user\\personal.tpl',
      1 => 1514678190,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/header.tpl' => 1,
    'file:common/secundaryMenu.tpl' => 1,
    'file:common/footer.tpl' => 1,
  ),
),false)) {
function content_5a517dca47ecc8_94909403 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:common/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<section id="personalProfile">
  <h1>
    Dados do utilizador
  </h1>

  <section>
    <h2>
      Dados de utilizador
    </h2>

    <p>
      <b>Nome: </b> <?php echo $_smarty_tpl->tpl_vars['userData']->value['nome'];?>

    </p>
    <p>
      <b>Email: </b> <?php echo $_smarty_tpl->tpl_vars['userData']->value['email'];?>

    </p>
    <p>
      <b>Nome de utilizador: </b> <?php echo $_smarty_tpl->tpl_vars['userData']->value['username'];?>

    </p>
    <p>
      <b>Telefone: </b> <?php echo $_smarty_tpl->tpl_vars['userData']->value['telefone'];?>

    </p>
  </section>

  <section>
    <h2>
      Dados de faturação
    </h2>

    <p>
      <b>NIF: </b> <?php echo $_smarty_tpl->tpl_vars['userData']->value['nif'];?>

    </p>
    <div id="addressBox">
      <p id="id"><b>Morada: </b></p>
      <p id="address"><?php echo $_smarty_tpl->tpl_vars['userData']->value['morada'];?>
</p>
      <p id="location">
      <?php if ((isset($_smarty_tpl->tpl_vars['postcode']->value))) {?>
        <?php echo $_smarty_tpl->tpl_vars['postcode']->value[0];?>
 &ndash; <?php echo $_smarty_tpl->tpl_vars['postcode']->value[1];?>

      <?php }?>
      <?php echo $_smarty_tpl->tpl_vars['userData']->value['localidade'];?>
</p>
    </div>
  </section>
</section>

<?php $_smarty_tpl->_subTemplateRender("file:common/secundaryMenu.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php $_smarty_tpl->_subTemplateRender("file:common/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
