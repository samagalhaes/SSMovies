<?php
/* Smarty version 3.1.30, created on 2018-01-06 21:49:39
  from "C:\www\TrabalhoPHP-2\templates\common\header.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a513663088e97_20411476',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5c9497ba82e28f4dc369c047f5df7626327ca052' => 
    array (
      0 => 'C:\\www\\TrabalhoPHP-2\\templates\\common\\header.tpl',
      1 => 1515262440,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/login.tpl' => 1,
  ),
),false)) {
function content_5a513663088e97_20411476 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>

<head>
  <title>SS Movies <?php if ((isset($_smarty_tpl->tpl_vars['TITLE']->value))) {?> | <?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
 <?php }?> </title>
  <link rel="icon" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
img/logo/favicon.png">

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/style.css">
  <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/fonts.css">
  <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/fontawesome-all.css">

  <?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-2.2.4.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
javascript/main.js"><?php echo '</script'; ?>
>

</head>

<body>
  <header>
    <section class="flexbox2">
      <div id="logo">
        <img src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
img/logo/logo.png" alt="SS Movies">
      </div>
      <?php $_smarty_tpl->_subTemplateRender("file:common/login.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    </section>
  </header>

  <nav>
    <ul>
      <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['mainMenu']->value, 'menuItem');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['menuItem']->value) {
?>
      <li>
        <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['menuItem']->value['url'];?>
" <?php if ((($_smarty_tpl->tpl_vars['BASE_URL']->value).($_smarty_tpl->tpl_vars['menuItem']->value['url']) == $_smarty_tpl->tpl_vars['REQUEST_URI']->value)) {?> class="selected" <?php }?>><?php echo $_smarty_tpl->tpl_vars['menuItem']->value['nome'];?>
</a>
      </li>
      <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

    </ul>

    <form id="search" action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/films/films.php" method="GET">
      <input type="text" name="search" value="" placeholder="Pesquisar">
      <button type="submit" name="searchButton"><i class="fas fa-search fa-lg"></i></button>
    </form>

    <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/order/cart.php" id="cart">
      <i class="fas fa-shopping-cart fa-lg"></i>
      <span><?php echo $_smarty_tpl->tpl_vars['CART_QT']->value;?>
</span>
    </a>
  </nav>

  <?php if (isset($_smarty_tpl->tpl_vars['SUCCESS_MESSAGES']->value) || isset($_smarty_tpl->tpl_vars['ERROR_MESSAGES']->value)) {?>
  <section id="message">
    <?php if (isset($_smarty_tpl->tpl_vars['SUCCESS_MESSAGES']->value)) {?> <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['SUCCESS_MESSAGES']->value, 'success');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['success']->value) {
?>
      <div class="success"><?php echo $_smarty_tpl->tpl_vars['success']->value;?>
 <a class="close" href="#">&#215;</a></div>
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
 <?php }?>

    <?php if (isset($_smarty_tpl->tpl_vars['ERROR_MESSAGES']->value)) {?> <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['ERROR_MESSAGES']->value, 'error');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['error']->value) {
?>
      <div class="error"><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
<a class="close" href="#">&#215;</a></div>
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
 <?php }?>
  </section>
  <?php }
}
}
