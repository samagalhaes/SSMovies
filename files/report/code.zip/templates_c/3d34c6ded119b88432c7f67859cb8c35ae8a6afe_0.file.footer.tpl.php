<?php
/* Smarty version 3.1.30, created on 2018-01-06 21:49:39
  from "C:\www\TrabalhoPHP-2\templates\common\footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a513663859373_15382516',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3d34c6ded119b88432c7f67859cb8c35ae8a6afe' => 
    array (
      0 => 'C:\\www\\TrabalhoPHP-2\\templates\\common\\footer.tpl',
      1 => 1510936461,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a513663859373_15382516 (Smarty_Internal_Template $_smarty_tpl) {
?>
  </body>
</html>
<?php }
}
