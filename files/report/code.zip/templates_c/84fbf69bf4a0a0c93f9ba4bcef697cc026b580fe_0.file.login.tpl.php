<?php
/* Smarty version 3.1.30, created on 2018-01-06 21:49:39
  from "C:\www\TrabalhoPHP-2\templates\common\login.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a5136632bbc45_10571085',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '84fbf69bf4a0a0c93f9ba4bcef697cc026b580fe' => 
    array (
      0 => 'C:\\www\\TrabalhoPHP-2\\templates\\common\\login.tpl',
      1 => 1514241345,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a5136632bbc45_10571085 (Smarty_Internal_Template $_smarty_tpl) {
if (($_smarty_tpl->tpl_vars['user']->value !== false)) {?>
	<div id="loginActive">
		Olá, <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/user/personal.php"><?php echo $_smarty_tpl->tpl_vars['user']->value;?>
</a>! <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/user/logout.php"><i class="fas fa-sign-out-alt fa-lg"></i></a>
	</div>
<?php } else { ?>
	<div id='login'>
		<form action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/user/login.php" method="POST">

			<p><input type="text" placeholder="username" name='username'></p>
			<p><input type="password" placeholder="password" name='password'></p>

			<input type="submit" name="login" value="Login">
			<input type="submit" name="register" value="Registar">
		</form>
	</div>
<?php }
}
}
