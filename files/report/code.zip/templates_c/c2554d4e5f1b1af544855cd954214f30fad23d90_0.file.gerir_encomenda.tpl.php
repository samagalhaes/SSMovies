<?php
/* Smarty version 3.1.30, created on 2018-01-07 03:04:04
  from "C:\www\TrabalhoPHP-2\templates\encomendas\gerir_encomenda.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a51801455dcd4_87054076',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c2554d4e5f1b1af544855cd954214f30fad23d90' => 
    array (
      0 => 'C:\\www\\TrabalhoPHP-2\\templates\\encomendas\\gerir_encomenda.tpl',
      1 => 1515266722,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/header.tpl' => 1,
    'file:common/footer.tpl' => 1,
  ),
),false)) {
function content_5a51801455dcd4_87054076 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_function_math')) require_once 'C:\\www\\TrabalhoPHP-2\\lib\\smarty\\plugins\\function.math.php';
if (!is_callable('smarty_function_html_options')) require_once 'C:\\www\\TrabalhoPHP-2\\lib\\smarty\\plugins\\function.html_options.php';
$_smarty_tpl->_subTemplateRender("file:common/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<section id="gerir_encomenda">
	<h1>
		Gerir encomenda
	</h1>
	<section class="tabela_encomendas">
		<table class="list">
			<tr>
				<th></th>
				<th class="left">Nome do filme</th>
				<th>qt</th>
				<th>Preço un.</th>
				<th>Preço</th>
			</tr>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['encomenda']->value, 'film');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['film']->value) {
?>
				<tr style="text-align:center">
					<td>
						<img src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
img/films/cover/covers/<?php echo $_smarty_tpl->tpl_vars['film']->value['id'];?>
.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['film']->value['nome'];?>
">
					</td>
					<td class="left">
						<?php echo $_smarty_tpl->tpl_vars['film']->value['nome'];?>

					</td>
					<td>
							<?php echo $_smarty_tpl->tpl_vars['film']->value['quantidade'];?>

					</td>
					<td>
						<?php echo $_smarty_tpl->tpl_vars['film']->value['preco'];?>
 €
					</td>
					<td>
						<?php if ($_smarty_tpl->tpl_vars['film']->value['quantidade'] && $_smarty_tpl->tpl_vars['film']->value['preco']) {?>
						 <?php echo smarty_function_math(array('equation'=>"x * y",'x'=>$_smarty_tpl->tpl_vars['film']->value['quantidade'],'y'=>$_smarty_tpl->tpl_vars['film']->value['preco']),$_smarty_tpl);?>
 €
						<?php }?>
					</td>
				</tr>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

		</table>
	</section>
	<section id="estado_encomenda" style="text-align: right; padding:1em 0 1.5em 0">
		<form method="POST" action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/encomendas/edit_estado.php?cod_encomenda=<?php echo $_smarty_tpl->tpl_vars['estado']->value['codigo'];?>
" autocomplete="on">
			<?php echo smarty_function_html_options(array('name'=>'estado','options'=>$_smarty_tpl->tpl_vars['myOptions']->value,'selected'=>$_smarty_tpl->tpl_vars['estado']->value['id']),$_smarty_tpl);?>

			<button class="check" type="submit" name="confirmar"><i class="fa fa-check-circle fa-lg" aria-hidden="true"></i></button>
		</form>
	</section>
	<section id="info_client">
			<p><b>Nome:</b> <?php echo $_smarty_tpl->tpl_vars['info']->value['nome'];?>
</p>
			<p><b>E-mail:</b> <?php echo $_smarty_tpl->tpl_vars['info']->value['email'];?>
</p>
			<p><b>Telefone:</b> <?php echo $_smarty_tpl->tpl_vars['info']->value['telefone'];?>
</p>
			<p><b>NIF:</b> <?php echo $_smarty_tpl->tpl_vars['info']->value['nif'];?>
</p>
			<p><b>Morada:</b> <?php echo $_smarty_tpl->tpl_vars['info']->value['morada'];?>
</p>
			<p><b>Código Postal:</b> <?php echo $_smarty_tpl->tpl_vars['info']->value['codigo_postal'];?>
</p>
	</section>

<?php $_smarty_tpl->_subTemplateRender("file:common/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
