<?php
/* Smarty version 3.1.30, created on 2018-01-07 02:13:10
  from "C:\www\TrabalhoPHP-2\templates\films\home.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a51742639a9c5_82596747',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'aabf47138c3a02258cc53ca0a858b8326bf7b5b5' => 
    array (
      0 => 'C:\\www\\TrabalhoPHP-2\\templates\\films\\home.tpl',
      1 => 1515205991,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/header.tpl' => 1,
    'file:common/footer.tpl' => 1,
  ),
),false)) {
function content_5a51742639a9c5_82596747 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:common/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<section>
  <h1>
    Últimos Filmes
  </h1>

  <section class="flexbox">
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['films']->value, 'film');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['film']->value) {
?>
    <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/films/film.php?id=<?php echo $_smarty_tpl->tpl_vars['film']->value['id'];?>
" class="filmbox">
      <div class="thumb">
        <img src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
img/films/movies-imgeffect.png" alt="">
      </div>
      <img src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
img/films/cover/thumbnails/<?php echo $_smarty_tpl->tpl_vars['film']->value['id'];?>
.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['film']->value['nome'];?>
" height="150px">
      <p class="filmname"><?php echo $_smarty_tpl->tpl_vars['film']->value['nome'];?>
</p>
      <div class="years">
        <span class="filmyear"><?php echo $_smarty_tpl->tpl_vars['film']->value['ano'];?>
</span>
        <span class="filmetar"><?php echo $_smarty_tpl->tpl_vars['film']->value['classificacao_etaria'];?>
</span>
      </div>
      <p class="filmpreco"><?php echo number_format($_smarty_tpl->tpl_vars['film']->value['preco'],2,',','.');?>
</p>
    </a>
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

  </section>

</section>

<aside id="loginData">
  <h1>
    Dados de Login
  </h1>

  <section id="user">
    <p class="title">Conta de Utilizador</p>
    <p><b>Username:</b> user</p>
    <p><b>Password:</b> user</p>
  </section>
  <section id="admin">
    <p class="title">Conta de Administrador</p>
    <p><b>Username:</b> admin</p>
    <p><b>Password:</b> admin</p>
  </section>
</aside>

<?php $_smarty_tpl->_subTemplateRender("file:common/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
