<?php
/* Smarty version 3.1.30, created on 2018-01-07 02:18:07
  from "C:\www\TrabalhoPHP-2\templates\other\about-us.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a51754f375a33_26438963',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f2840641d5c6405a0a379d16ab0344f4f4f2b846' => 
    array (
      0 => 'C:\\www\\TrabalhoPHP-2\\templates\\other\\about-us.tpl',
      1 => 1515206578,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/header.tpl' => 1,
    'file:common/footer.tpl' => 1,
  ),
),false)) {
function content_5a51754f375a33_26438963 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:common/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<section>
  <h1>
    Sobre nós
  </h1>
  
  <section class="about-us">
	<p>Somos dois estudantes de Engenharia Eletrotécnica na Faculdade de Engenharia da Universidade do Porto e estamos a realizar este trabalho no âmbito da UC de Sistemas de Informação Empresariais.</p>
	<p>Ambos gostamos de ver filmes no nosso tempo livre, por isso decidimos que seria interessante que o nosso trabalho fosse sobre este assunto, já que não só nos permite consolidar os conhecimentos que se pretendem adquirir, mas também conseguimos descobrir filmes que possam ser interessantes.</p>
	<p>Esperamos que desfrute da sua visita!</p>
	
	<section class="flexbox3">
		<img src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
img/authors/sandro.jpg">
		<img src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
img/authors/sergio.jpg">
	</section>
	
	<section class="flexbox3">
		<section class="textbox">
			<p>Sandro Magalhães</p>
			<p>up201304932@fe.up.pt</p>
		</section>
		<section class="textbox">
			<p>Sérgio Fernandes</p>
			<p>up201305659@fe.up.pt</p>
		</section>
	</section>
  </section>
</section>

<?php $_smarty_tpl->_subTemplateRender("file:common/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
