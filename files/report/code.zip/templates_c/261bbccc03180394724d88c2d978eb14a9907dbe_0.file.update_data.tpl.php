<?php
/* Smarty version 3.1.30, created on 2018-01-07 02:54:28
  from "C:\www\TrabalhoPHP-2\templates\user\update_data.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a517dd4583e56_30489826',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '261bbccc03180394724d88c2d978eb14a9907dbe' => 
    array (
      0 => 'C:\\www\\TrabalhoPHP-2\\templates\\user\\update_data.tpl',
      1 => 1514678316,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/header.tpl' => 1,
    'file:common/secundaryMenu.tpl' => 1,
    'file:common/footer.tpl' => 1,
  ),
),false)) {
function content_5a517dd4583e56_30489826 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:common/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<section id="updateData">
  <h1>
    Atualizar dados
  </h1>

  <section>
    <form id="formRegister" action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/user/update_data.php" method="POST">
      <h2>
        Dados do utilizador
      </h2>

      <p>
        <input type="text" name="name" placeholder="Nome" value="<?php echo $_smarty_tpl->tpl_vars['userData']->value['nome'];?>
" required>
      </p>
      <p>
        <input type="email" name="email" placeholder="E-mail" value="<?php echo $_smarty_tpl->tpl_vars['userData']->value['email'];?>
"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"  required>
      </p>
      <p>
        <input type="text" name="username" placeholder="Nome de utilizador" value="<?php echo $_smarty_tpl->tpl_vars['userData']->value['username'];?>
" required disabled>
      </p>
      <p>
        <input type="tel" name="telephone" placeholder="Telefone" value="<?php echo $_smarty_tpl->tpl_vars['userData']->value['telefone'];?>
"  pattern="\d{9}"  title="Insira um contacto telefónico com 9 dígitos.">
      </p>


      <h2>
        Dados de facturação
      </h2>

      <p>
        <input type="text" name="nif" placeholder="NIF" value="<?php echo $_smarty_tpl->tpl_vars['userData']->value['nif'];?>
">
      </p>
      <p>
        <input type="text" name="address" placeholder="Morada" value="<?php echo $_smarty_tpl->tpl_vars['userData']->value['morada'];?>
">
      </p>
      <p>
        <input type="text" name="postcode1" value="<?php if (isset($_smarty_tpl->tpl_vars['postcode']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['postcode']->value[0];?>
 <?php }?>" placeholder="0000"  pattern="\d{4}"  title="Insira a primeira parte do código postal com 4 dígitos"> &ndash;
        <input type="text" name="postcode2" value="<?php if (isset($_smarty_tpl->tpl_vars['postcode']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['postcode']->value[1];?>
 <?php }?>" placeholder="000"  pattern="\d{3}"  title="Insira a segunda parte do código postal com 3 dígitos">
        <input type="text" name="locality" placeholder="Localidade" value="<?php echo $_smarty_tpl->tpl_vars['userData']->value['localidade'];?>
">
      </p>

      <h2>
        Confirmar e alterar palavra-passe
      </h2>

      <p>
        <input type="password" name="password" placeholder="Password" required>
      </p>
      <p>
        <input type="password" name="confirmPassword" placeholder="Confirmar password" required>
      </p>

      <div class="submit">
        <input type="submit" name="update" value="Atualizar">
      </div>
    </form>
  </section>
</section>

<?php $_smarty_tpl->_subTemplateRender("file:common/secundaryMenu.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php $_smarty_tpl->_subTemplateRender("file:common/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
