<?php
/* Smarty version 3.1.30, created on 2017-12-06 10:14:21
  from "/usr/users2/mieec2013/up201304932/public_html/trabalhosSiem/TrabalhoPHP-2/templates/common/footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a27c2fde000b3_83335677',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'eb57437788742695dbf8d66bc0416901a2c6313e' => 
    array (
      0 => '/usr/users2/mieec2013/up201304932/public_html/trabalhosSiem/TrabalhoPHP-2/templates/common/footer.tpl',
      1 => 1510936461,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a27c2fde000b3_83335677 (Smarty_Internal_Template $_smarty_tpl) {
?>
  </body>
</html>
<?php }
}
