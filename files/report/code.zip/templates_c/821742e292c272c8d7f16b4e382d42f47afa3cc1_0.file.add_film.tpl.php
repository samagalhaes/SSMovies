<?php
/* Smarty version 3.1.30, created on 2018-01-06 21:49:38
  from "C:\www\TrabalhoPHP-2\templates\films\add_film.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a513662cf0530_28877270',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '821742e292c272c8d7f16b4e382d42f47afa3cc1' => 
    array (
      0 => 'C:\\www\\TrabalhoPHP-2\\templates\\films\\add_film.tpl',
      1 => 1515271776,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/header.tpl' => 1,
    'file:common/secundaryMenu.tpl' => 1,
    'file:common/footer.tpl' => 1,
  ),
),false)) {
function content_5a513662cf0530_28877270 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:common/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<section id="addFilm">
  <h1>
    Adicionar Filme
  </h1>

  <section>
    <form class="" action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/films/addFilm.php" method="POST" enctype="multipart/form-data">
      <input type="text" name="title" value="<?php if (isset($_smarty_tpl->tpl_vars['FORM_VALUES']->value)) {
echo $_smarty_tpl->tpl_vars['FORM_VALUES']->value['title'];
}?>" placeholder="Título do filme" required>

      <span id="year">
        Ano
        <input type="text" name="year" value="<?php if (isset($_smarty_tpl->tpl_vars['FORM_VALUES']->value)) {
echo $_smarty_tpl->tpl_vars['FORM_VALUES']->value['year'];
}?>"  pattern="\d{4}"  required>
      </span>

      <span id="classEtaria">
        Classificação etária

        <select name="classEtaria">
          <option value="3" <?php if (isset($_smarty_tpl->tpl_vars['FORM_VALUES']->value)) {
if (($_smarty_tpl->tpl_vars['FORM_VALUES']->value['classEtaria'] == 3)) {?>selected<?php }
}?>>M/3</option>
          <option value="6" <?php if (isset($_smarty_tpl->tpl_vars['FORM_VALUES']->value)) {
if (($_smarty_tpl->tpl_vars['FORM_VALUES']->value['classEtaria'] == 6)) {?>selected<?php }
}?>>M/6</option>
          <option value="12" <?php if (isset($_smarty_tpl->tpl_vars['FORM_VALUES']->value)) {
if (($_smarty_tpl->tpl_vars['FORM_VALUES']->value['classEtaria'] == 12)) {?>selected<?php }
}?>>M/12</option>
          <option value="14" <?php if (isset($_smarty_tpl->tpl_vars['FORM_VALUES']->value)) {
if (($_smarty_tpl->tpl_vars['FORM_VALUES']->value['classEtaria'] == 14)) {?>selected<?php }
}?>>M/14</option>
          <option value="16" <?php if (isset($_smarty_tpl->tpl_vars['FORM_VALUES']->value)) {
if (($_smarty_tpl->tpl_vars['FORM_VALUES']->value['classEtaria'] == 16)) {?>selected<?php }
}?>>M/16</option>
          <option value="18" <?php if (isset($_smarty_tpl->tpl_vars['FORM_VALUES']->value)) {
if (($_smarty_tpl->tpl_vars['FORM_VALUES']->value['classEtaria'] == 18)) {?>selected<?php }
}?>>M/18</option>
        </select>
      </span>

      <span id="duration">
        Duração
        <input type="" name="duration" value="<?php if (isset($_smarty_tpl->tpl_vars['FORM_VALUES']->value)) {
echo $_smarty_tpl->tpl_vars['FORM_VALUES']->value['duration'];
}?>" placeholder="min"  pattern="[0-9]+"  required>
      </span>

      <span id="imdb">
        IMDB
        <input type="text" name="imdb" value="<?php if (isset($_smarty_tpl->tpl_vars['FORM_VALUES']->value)) {
echo $_smarty_tpl->tpl_vars['FORM_VALUES']->value['imdb'];
}?>"  pattern="[0-9]*\.?[0-9]*" >
      </span>

      <span id="genre">
        Género

        <select name="genre">
          <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['genres']->value, 'genre');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['genre']->value) {
?>
            <option value="<?php echo $_smarty_tpl->tpl_vars['genre']->value['id'];?>
"<?php if (isset($_smarty_tpl->tpl_vars['FORM_VALUES']->value)) {
if (($_smarty_tpl->tpl_vars['FORM_VALUES']->value['genre'] == $_smarty_tpl->tpl_vars['genre']->value['id'])) {?>selected<?php }
}?>><?php echo $_smarty_tpl->tpl_vars['genre']->value['nome'];?>
</option>
          <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

        </select>
      </span>

      <span id="cover">
        Cover
        <input type="file" name="cover" value="" required>
      </span>

      <span id="trailer">
        Trailer
        <input type="text" name="trailer" value="<?php if (isset($_smarty_tpl->tpl_vars['FORM_VALUES']->value)) {
echo $_smarty_tpl->tpl_vars['FORM_VALUES']->value['trailer'];
}?>" placeholder="YouTube code"  pattern="[a-zA-Z0-9-]+"  title="Introduza apenas o código do YouTube" required>
      </span>

      <span id="sinopse">
        Sinopse
        <textarea name="sinopse" rows="8" cols="80" required><?php if (isset($_smarty_tpl->tpl_vars['FORM_VALUES']->value)) {
echo $_smarty_tpl->tpl_vars['FORM_VALUES']->value['sinopse'];
}?></textarea>
      </span>

      <span id="price">
        Preço
        <input type="text" name="price" value="<?php if (isset($_smarty_tpl->tpl_vars['FORM_VALUES']->value)) {
echo $_smarty_tpl->tpl_vars['FORM_VALUES']->value['price'];
}?>" placeholder="0,00€"  pattern="[-+]?[0-9]*\.?[0-9]*"  required>
      </span>
      <span id="qt">
        <input type="text" name="qt" placeholder="qt" value="<?php if (isset($_smarty_tpl->tpl_vars['FORM_VALUES']->value)) {
echo $_smarty_tpl->tpl_vars['FORM_VALUES']->value['qt'];
}?>"  pattern="[0-9]+"  required>
      </span>
      <div class="submit">
        <input type="submit" name="add" value="Adicionar">
      </div>
    </form>
  </section>

</section>

<?php $_smarty_tpl->_subTemplateRender("file:common/secundaryMenu.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php $_smarty_tpl->_subTemplateRender("file:common/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
