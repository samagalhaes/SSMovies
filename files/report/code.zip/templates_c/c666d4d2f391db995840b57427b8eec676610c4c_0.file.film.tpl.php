<?php
/* Smarty version 3.1.30, created on 2018-01-07 23:48:03
  from "C:\www\TrabalhoPHP-2\templates\films\film.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a52a3a321e888_35945927',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c666d4d2f391db995840b57427b8eec676610c4c' => 
    array (
      0 => 'C:\\www\\TrabalhoPHP-2\\templates\\films\\film.tpl',
      1 => 1515205611,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/header.tpl' => 1,
    'file:common/footer.tpl' => 1,
  ),
),false)) {
function content_5a52a3a321e888_35945927 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:common/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<section id="film">
  <h1>
    Detalhes do filme
  </h1>

  <section id="filmDetails">
    <img src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
img/films/cover/covers/<?php echo $_smarty_tpl->tpl_vars['film']->value['id'];?>
.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['film']->value['nome'];?>
">

    <section id="filmHeader">
      <p id="filmName">
        <?php echo $_smarty_tpl->tpl_vars['film']->value['nome'];?>

      </p>
      <p id="filmParticulars">
        <?php echo $_smarty_tpl->tpl_vars['film']->value['ano'];?>
 | M<?php echo $_smarty_tpl->tpl_vars['film']->value['classificacao_etaria'];?>
 | <?php echo $_smarty_tpl->tpl_vars['film']->value['genero'];?>
 | <?php echo $_smarty_tpl->tpl_vars['film']->value['duracao'];?>
min. | IMDB <?php echo $_smarty_tpl->tpl_vars['film']->value['pontuacao_imdb'];?>

      </p>

      <p id="preco">
        <span id="<?php echo $_smarty_tpl->tpl_vars['available']->value;?>
"> </span> <?php echo number_format($_smarty_tpl->tpl_vars['film']->value['preco'],2,',','.');?>

      </p>
    </section>

    <section id="sinopse">
      <?php echo $_smarty_tpl->tpl_vars['film']->value['sinopse'];?>

    </section>

    <section id="trailer">
      <iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/<?php echo $_smarty_tpl->tpl_vars['film']->value['link_trailer'];?>
?rel=0&amp;showinfo=0" frameborder="0" gesture="media" allow="encrypted-media" frameborder="0" allowfullscreen></iframe>
    </section>

    <section id="buttons">
      <?php if ($_smarty_tpl->tpl_vars['admin']->value) {?>
      <form class="" action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/films/editFilm.php" method="post">
        <input type="text" name="id" value="<?php echo $_smarty_tpl->tpl_vars['film']->value['id'];?>
" hidden>
        <button type="submit" name="edit" value=""> <i class="fas fa-edit fa-lg"></i> </button>
        <button type="submit" name="delete" value=""> <i class="fas fa-trash-alt fa-lg"></i> </button>
      </form>
      <?php }?>

      <form action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/order/cart.php" method="GET">
        <input type="text" name="id" value="<?php echo $_smarty_tpl->tpl_vars['film']->value['id'];?>
" hidden>
        <input type="submit" name="buy" value="Comprar" <?php if (($_smarty_tpl->tpl_vars['available']->value == 'red')) {?> disabled <?php }?>>
      </form>
    </section>
  </section>
</section>

<?php $_smarty_tpl->_subTemplateRender("file:common/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
