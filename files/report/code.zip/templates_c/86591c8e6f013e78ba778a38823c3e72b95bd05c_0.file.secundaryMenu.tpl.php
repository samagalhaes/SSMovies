<?php
/* Smarty version 3.1.30, created on 2018-01-06 21:49:39
  from "C:\www\TrabalhoPHP-2\templates\common\secundaryMenu.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a5136634caca3_51794494',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '86591c8e6f013e78ba778a38823c3e72b95bd05c' => 
    array (
      0 => 'C:\\www\\TrabalhoPHP-2\\templates\\common\\secundaryMenu.tpl',
      1 => 1514677392,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a5136634caca3_51794494 (Smarty_Internal_Template $_smarty_tpl) {
?>
<aside id="secundaryMenu">
  <h1>&nbsp;</h1>

  <nav>
    <ul>
      <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['secundaryMenuUser']->value, 'menuItem');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['menuItem']->value) {
?>
      <li>
        <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['menuItem']->value['url'];?>
" <?php if ((($_smarty_tpl->tpl_vars['BASE_URL']->value).($_smarty_tpl->tpl_vars['menuItem']->value['url']) == $_smarty_tpl->tpl_vars['REQUEST_URI']->value)) {?> class="selected" <?php }?>><?php echo $_smarty_tpl->tpl_vars['menuItem']->value['nome'];?>
</a>
      </li>
      <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

      <?php if ((isset($_smarty_tpl->tpl_vars['secundaryMenuAdmin']->value))) {?>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['secundaryMenuAdmin']->value, 'menuItem');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['menuItem']->value) {
?>
        <li>
          <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['menuItem']->value['url'];?>
" <?php if ((($_smarty_tpl->tpl_vars['BASE_URL']->value).($_smarty_tpl->tpl_vars['menuItem']->value['url']) == $_smarty_tpl->tpl_vars['REQUEST_URI']->value)) {?> class="selected" <?php }?>><?php echo $_smarty_tpl->tpl_vars['menuItem']->value['nome'];?>
</a>
        </li>
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

      <?php }?>
    </ul>
  </nav>

</aside>
<?php }
}
