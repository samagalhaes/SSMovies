create table estado(
   id serial primary key,
   designacao varchar (20) unique not null
)